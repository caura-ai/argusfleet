# ArgusFleet — Evaluation Bundle (Memory Fleet vs Mem0)

Self-contained bundle for the evaluation harness behind
*"Governed Shared Memory for Multi-Agent LLM Systems"*. It contains the
complete result datasets, a dashboard generator that visualises them, and
the harness code that generates and runs the test workloads against the
two evaluated platforms (Memory Fleet and Mem0).

Everything needed is inside this archive — no external repository is
required.

```
argusfleet-mem0-bundle/
├── README.md                  ← this file
├── data/
│   ├── runs/                  every experiment run (events.jsonl, CSVs, plots)
│   ├── reports/               consolidated cross-experiment reports
│   └── traces/                canonical runs of record cited in the paper
└── code/
    ├── dashboard/
    │   └── build_dashboard.py builds a single-file HTML results dashboard
    └── argusfleet/            the harness: generates + runs the tests
        ├── cli.py, __main__.py, __init__.py
        ├── harness/           HTTP clients (Memory Fleet + Mem0), runner, metrics, plots
        ├── experiments/       leakage, contradiction, provenance, propagation
        ├── configs/           experiment YAMLs (configs/mem0/ = Mem0 variants)
        └── tests/             offline unit tests (mocked servers, no network)
```

## 1. Data

All workloads are **synthetic and seed-derived** — the harness synthesises
tenants, fleets, agents, and memory content from the run seed. No real
user data is involved.

### `data/runs/` — one directory per experiment run

Directory name format: `<UTC-timestamp>-<label>-seed<N>/`. Each contains:

| File | What it is |
|---|---|
| `events.jsonl` | The authoritative event stream. First record is a `run_start` envelope (run id, experiment, backend, seed, base URL, synthesized agent roster); every probe/write/read event follows with timestamps and outcomes. |
| `<experiment>.csv` | Per-probe rows (e.g. `leakage.csv`: one row per access/discovery probe with expected vs observed outcome). |
| `summary.csv` | `metric,value` pairs — headline rates, counts, and latency percentiles. Derived from the JSONL, never from in-memory state. |
| `*.png` | Plots rendered from the same JSONL. |

Runs whose label contains `smoke` are small-N sanity runs; the full runs
are the ones to quote.

### `data/traces/` — runs of record

Canonical copies of the runs whose numbers appear in the paper, with a
README explaining which run backs which table/figure, why there are
multiple contradiction runs (write admission is stochastic), and the
remediation re-probe (`agent_scope_leakage-2f77f908`) for the GET-by-id
enforcement gap.

### `data/reports/` — consolidated reports

Markdown summaries aggregating the latest run per (platform, experiment),
with the plot PNGs copied alongside. `20260713T161245Z/` is the first
report that includes both Memory Fleet and Mem0 sections.

## 2. Dashboard

`code/dashboard/build_dashboard.py` builds a **single self-contained HTML
file** from `data/` — all plots embedded, works offline, light/dark theme,
keyboard-accessible tooltips, and a table view for every chart.

Requires only Python 3.10+ (standard library, no packages):

```bash
cd code/dashboard
python build_dashboard.py            # auto-locates ../../data
# → dashboard.html  — open it in any browser
```

Options: `--data <dir>` to point at a different data folder, `--out
<file>` for the output path, `--include-smoke` to let smoke runs into the
headline selection.

The dashboard shows:

- **Headline rates** — scope/search leakage, contradiction detection,
  stale reads, provenance completeness, and propagation visibility,
  side by side per platform.
- **Latency p50** per operation type on one shared axis.
- **Per-experiment sections** — full metric tables and the run plots.
- **All-runs index** — every run in `data/`, newest first.

## 3. Running the tests against Mem0

`code/argusfleet/` is the complete test generator + runner. It synthesises
the multi-agent workloads from a seed and executes the four experiments
against a live platform through a backend seam:

- **Memory Fleet** (default backend) — talks to the Memory Fleet HTTP API.
- **Mem0** — `harness/mem0_client.py` maps the harness identity model onto
  the Mem0 platform API (tenant→`user_id`, fleet→`run_id`,
  writer→metadata) so the same probe geometry runs unchanged.

### Setup

Requires Python 3.12+.

```bash
cd code/argusfleet
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .

cp .env.example .env                 # then edit .env
```

For Mem0, set in `.env`:

```
MEM0_API_KEY=<your Mem0 platform API key>
```

### Run

```bash
# All four experiments against Mem0 (auto-picks configs/mem0/*.yaml):
python -m argusfleet run all --backend mem0

# A single experiment:
python -m argusfleet run leakage --backend mem0
python -m argusfleet run contradiction --backend mem0

# Consolidated report over whatever has been run:
python -m argusfleet report latest
```

Results land in `outputs/runs/<timestamp>-<experiment>-seed<N>/` in the
same format as `data/runs/` — point the dashboard at them with
`--data outputs` (or copy them into `data/runs/`).

The Mem0-specific configs in `configs/mem0/` keep the probe geometry
identical to the Memory Fleet runs so rates are directly comparable; the file
headers document the identifier mapping and the platform-specific knobs
(e.g. `write_mode: strong` for contradiction — LLM inference — vs
`write_mode: fast` for propagation — verbatim storage).

### Offline unit tests

```bash
pip install -e ".[dev]"
pytest -q
```

The suite (including `tests/test_mem0_client.py` and
`tests/test_contradiction_mem0.py`) runs against mocked servers — no
network, no API keys needed.

## 4. Reproducibility

- Every run records its seed, base URL, tenant/user IDs, and the full
  event stream in `events.jsonl`. Same seed + same server state ⇒ same
  probe-level outcomes.
- `summary.csv` and the PNGs are derived from the JSONL, so they can be
  re-materialised at any time (`python -m argusfleet plot latest`).
- Headline leak/miss rates carry 95% Wilson confidence intervals
  (`*_ci95_lo` / `*_ci95_hi` in `summary.csv`); `0/N` is reported with
  its interval, never as "zero leakage".
- Live platforms accumulate state; for credible numbers run against a
  clean tenant/user. `run all` purges the configured tenants before each
  experiment and after the suite by default (`--no-cleanup` disables).

## License

Code: Apache-2.0. Data: synthetic, generated by the harness.
