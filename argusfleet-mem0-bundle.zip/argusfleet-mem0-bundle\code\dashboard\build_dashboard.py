#!/usr/bin/env python3
"""Build a self-contained HTML dashboard from ArgusFleet run outputs.

Standard library only — no third-party dependencies. Point it at the
bundle's ``data/`` directory (containing ``runs/`` and optionally
``traces/``) and it writes a single ``dashboard.html`` with every plot
embedded, so the file can be opened or shared on its own.

    python build_dashboard.py                  # auto-locates ../../data
    python build_dashboard.py --data path/to/data --out dashboard.html
    python build_dashboard.py --include-smoke  # let smoke runs into the headline

Headline selection mirrors the harness report aggregator: the most recent
run per (backend, experiment), keyed on the ``run_start`` event timestamp.
Runs whose label contains "smoke" are excluded from the headline by
default (they use tiny N and would shadow the runs of record) but always
appear in the all-runs table.
"""

from __future__ import annotations

import argparse
import base64
import csv
import html
import json
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

KNOWN_EXPERIMENTS = ("leakage", "contradiction", "provenance", "propagation")

BACKEND_NAMES = {"memoryfleet": "Memory Fleet", "mem0": "Mem0"}

EXPERIMENT_BLURBS = {
    "leakage": "Cross-scope unauthorized retrievals — the security envelope. "
    "Every probe issues an authoritative GET-by-id access check and a "
    "secondary semantic-search discovery check.",
    "contradiction": "Detection of conflicting writes over the same fact "
    "(RDF triple), plus stale-read behaviour after the conflict.",
    "provenance": "End-to-end reconstruction of derivation chains: "
    "completeness, accuracy, and depth fidelity per chain.",
    "propagation": "Fleet-sibling visibility, cross-fleet isolation, and "
    "ownership redistribution timing.",
}

# Metric order copied from the harness report aggregator so both tools
# lead with the same numbers.
HEADLINE_METRICS: dict[str, list[str]] = {
    "leakage": [
        "n_probes", "n_expected_allow", "n_expected_deny", "n_leaks",
        "leak_rate", "leak_rate_ci95_lo", "leak_rate_ci95_hi",
        "n_misses", "miss_rate", "miss_rate_ci95_lo", "miss_rate_ci95_hi",
        "search_leak_rate", "search_miss_rate",
        "access_latency_p50", "access_latency_p95",
        "search_latency_p50", "search_latency_p95",
    ],
    "contradiction": [
        "n_facts_runs", "detection_rate", "stale_read_rate",
        "write_latency_p50", "write_latency_p95",
    ],
    "provenance": [
        "n_chains", "completeness_rate", "accuracy_rate",
        "depth_fidelity_rate", "fetch_latency_p50", "fetch_latency_p95",
    ],
    "propagation": [
        "fleet_visibility_rate", "leak_rate", "n_missed_propagations",
        "ownership_transfer_rate", "t_visible_p50", "t_visible_p95",
    ],
}

# (experiment, metric, row label, which direction is good)
RATE_ROWS = [
    ("leakage", "leak_rate", "Scope leak rate", "lower"),
    ("leakage", "search_leak_rate", "Search leak rate", "lower"),
    ("contradiction", "detection_rate", "Contradiction detection", "higher"),
    ("contradiction", "stale_read_rate", "Stale read rate", "lower"),
    ("provenance", "completeness_rate", "Provenance completeness", "higher"),
    ("propagation", "fleet_visibility_rate", "Fleet visibility", "higher"),
    ("propagation", "leak_rate", "Cross-fleet leak rate", "lower"),
]

LATENCY_ROWS = [
    ("leakage", "access_latency_p50", "Access GET p50"),
    ("leakage", "search_latency_p50", "Search p50"),
    ("contradiction", "write_latency_p50", "Write p50"),
    ("provenance", "fetch_latency_p50", "Provenance fetch p50"),
    ("propagation", "t_visible_p50", "Time to visibility p50"),
]


@dataclass
class Run:
    run_id: str
    experiment: str
    backend: str
    seed: int | None
    started_at: str | None
    run_dir: Path
    source: str  # "runs" or "traces"
    summary: dict[str, float] = field(default_factory=dict)
    plots: list[Path] = field(default_factory=list)

    @property
    def label(self) -> str:
        # run_id format: <UTC-ts>-<label>-seed<N>
        m = re.match(r"^\d{8}T\d{6}Z-(.*)-seed\d+$", self.run_id)
        return m.group(1) if m else self.run_id

    @property
    def is_smoke(self) -> bool:
        return "smoke" in self.label.lower()


# ---------------------------------------------------------------------- #
# Discovery                                                               #
# ---------------------------------------------------------------------- #


def _read_run_start(events_path: Path) -> dict | None:
    try:
        with open(events_path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                if rec.get("event") == "run_start":
                    return rec
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    return None


def _read_summary(summary_path: Path) -> dict[str, float]:
    out: dict[str, float] = {}
    if not summary_path.exists():
        return out
    try:
        with open(summary_path, encoding="utf-8") as fh:
            for row in csv.DictReader(fh):
                name = (row.get("metric") or "").strip()
                if not name:
                    continue
                try:
                    out[name] = float(row.get("value", ""))
                except (TypeError, ValueError):
                    pass
    except OSError:
        pass
    return out


def discover_runs(data_dir: Path) -> list[Run]:
    """Scan ``<data>/runs`` and ``<data>/traces`` (plus ``data`` itself)
    for run directories, dedupe by run_id (runs/ wins over traces/)."""
    roots: list[tuple[str, Path]] = []
    for name in ("runs", "traces"):
        p = data_dir / name
        if p.is_dir():
            roots.append((name, p))
    if not roots:
        roots.append(("runs", data_dir))

    by_id: dict[str, Run] = {}
    for source, root in roots:
        for run_dir in sorted(root.iterdir()):
            if not run_dir.is_dir():
                continue
            start = _read_run_start(run_dir / "events.jsonl")
            if not start:
                continue
            data = start.get("data") or {}
            run = Run(
                run_id=str(data.get("run_id") or run_dir.name),
                experiment=str(data.get("experiment") or "unknown"),
                backend=str(data.get("backend") or "memoryfleet"),
                seed=data.get("seed"),
                started_at=start.get("ts"),
                run_dir=run_dir,
                source=source,
                summary=_read_summary(run_dir / "summary.csv"),
                plots=sorted(run_dir.glob("*.png")),
            )
            existing = by_id.get(run.run_id)
            if existing is None or (existing.source == "traces" and source == "runs"):
                by_id[run.run_id] = run
    return sorted(by_id.values(), key=lambda r: r.started_at or "", reverse=True)


def headline_runs(runs: list[Run], include_smoke: bool) -> dict[tuple[str, str], Run]:
    latest: dict[tuple[str, str], Run] = {}
    for run in runs:
        if run.experiment not in KNOWN_EXPERIMENTS:
            continue
        if run.is_smoke and not include_smoke:
            continue
        key = (run.backend, run.experiment)
        cur = latest.get(key)
        if cur is None or (run.started_at or "") > (cur.started_at or ""):
            latest[key] = run
    return latest


# ---------------------------------------------------------------------- #
# Formatting                                                              #
# ---------------------------------------------------------------------- #


def esc(s: object) -> str:
    return html.escape(str(s), quote=True)


def fmt_value(v: object) -> str:
    if v is None:
        return "—"
    if isinstance(v, float):
        if v != v:  # NaN
            return "—"
        if v == int(v) and abs(v) < 1e15:
            return f"{int(v):,}"
        if abs(v) >= 1000:
            return f"{v:,.1f}"
        if abs(v) < 0.01 and v != 0:
            return f"{v:.3g}"
        return f"{v:.4f}".rstrip("0").rstrip(".") or "0"
    return str(v)


def fmt_rate(v: float | None) -> str:
    if v is None:
        return "—"
    return f"{v:.3f}".rstrip("0").rstrip(".") or "0"


def fmt_ms(v: float | None) -> str:
    if v is None:
        return "—"
    return f"{v:,.0f} ms"


def nice_ceiling(v: float) -> float:
    """Round up to a clean axis maximum (1/2/2.5/5 × 10^k)."""
    if v <= 0:
        return 1.0
    import math

    exp = math.floor(math.log10(v))
    for mult in (1, 2, 2.5, 5, 10):
        cand = mult * 10 ** exp
        if cand >= v:
            return cand
    return 10 ** (exp + 1)


# ---------------------------------------------------------------------- #
# SVG chart                                                               #
# ---------------------------------------------------------------------- #

# Geometry constants (see marks spec: thin bars, 4px rounded data-end
# square at the baseline, 2px surface gap between adjacent bars).
BAR_H = 13
BAR_GAP = 2
ROW_PAD = 8
GUTTER = 230
PLOT_W = 500
RIGHT_PAD = 130
CHART_W = GUTTER + PLOT_W + RIGHT_PAD


def _rounded_right_bar(x: float, y: float, w: float, h: float, r: float = 4) -> str:
    """Bar path with a rounded data-end (right) and square baseline (left)."""
    if w <= 0:
        return ""
    r = min(r, w, h / 2)
    return (
        f"M {x:.1f} {y:.1f} L {x + w - r:.1f} {y:.1f} "
        f"Q {x + w:.1f} {y:.1f} {x + w:.1f} {y + r:.1f} "
        f"L {x + w:.1f} {y + h - r:.1f} "
        f"Q {x + w:.1f} {y + h:.1f} {x + w - r:.1f} {y + h:.1f} "
        f"L {x:.1f} {y + h:.1f} Z"
    )


def grouped_hbar(
    rows: list[dict],
    backends: list[str],
    x_max: float,
    ticks: list[float],
    tick_label,
    tip_value,
) -> str:
    """Render a grouped horizontal bar chart as inline SVG.

    ``rows``: [{"label": str, "values": {backend: float|None}, "note": str}]
    Bars use CSS vars --series-<backend>; labels/ticks use text tokens.
    """
    n_series = len(backends)
    group_h = n_series * BAR_H + (n_series - 1) * BAR_GAP
    row_h = group_h + 2 * ROW_PAD
    top = 6
    plot_h = len(rows) * row_h
    height = top + plot_h + 28  # + x-axis tick band

    def sx(v: float) -> float:
        return GUTTER + (min(v, x_max) / x_max) * PLOT_W

    parts: list[str] = [
        f'<svg viewBox="0 0 {CHART_W} {height}" role="img" '
        f'style="width:100%;height:auto;display:block" '
        f'font-family="system-ui, -apple-system, \'Segoe UI\', sans-serif">'
    ]
    # Gridlines: solid hairlines, one step off the surface.
    for t in ticks:
        x = sx(t)
        parts.append(
            f'<line x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{top + plot_h}" '
            f'stroke="var(--grid)" stroke-width="1"/>'
        )
        parts.append(
            f'<text x="{x:.1f}" y="{top + plot_h + 18}" text-anchor="middle" '
            f'font-size="11" fill="var(--muted)" '
            f'style="font-variant-numeric:tabular-nums">{esc(tick_label(t))}</text>'
        )
    # Baseline.
    parts.append(
        f'<line x1="{GUTTER}" y1="{top}" x2="{GUTTER}" y2="{top + plot_h}" '
        f'stroke="var(--axis)" stroke-width="1"/>'
    )

    for i, row in enumerate(rows):
        y0 = top + i * row_h
        # Row label, vertically centred on the group.
        parts.append(
            f'<text x="{GUTTER - 12}" y="{y0 + row_h / 2 + 4}" text-anchor="end" '
            f'font-size="12" fill="var(--text-secondary)">{esc(row["label"])}</text>'
        )
        for j, backend in enumerate(backends):
            v = row["values"].get(backend)
            by = y0 + ROW_PAD + j * (BAR_H + BAR_GAP)
            if v is not None and v > 0:
                w = max(sx(v) - GUTTER, 1.0)
                parts.append(
                    f'<path d="{_rounded_right_bar(GUTTER, by, w, BAR_H)}" '
                    f'fill="var(--series-{esc(backend)})"/>'
                )
                label_x = GUTTER + w + 8
            else:
                label_x = GUTTER + 8
            # Value at the tip, in text tokens (never the series colour).
            parts.append(
                f'<text x="{label_x:.1f}" y="{by + BAR_H - 3}" font-size="11" '
                f'fill="var(--text-primary)" '
                f'style="font-variant-numeric:tabular-nums">{esc(tip_value(v))}</text>'
            )
            # Generous invisible hit target for hover/focus tooltip.
            tip = (
                f"{BACKEND_NAMES.get(backend, backend)} — {row['label']}: "
                f"{tip_value(v)}{row.get('notes', {}).get(backend, '')}"
            )
            hit_y = y0 + j * (row_h / n_series)
            parts.append(
                f'<rect x="{GUTTER}" y="{hit_y:.1f}" width="{PLOT_W + RIGHT_PAD - 10}" '
                f'height="{row_h / n_series:.1f}" fill="transparent" tabindex="0" '
                f'data-tip="{esc(tip)}"/>'
            )
    parts.append("</svg>")
    return "".join(parts)


def legend(backends: list[str]) -> str:
    items = "".join(
        f'<span class="key"><span class="swatch" '
        f'style="background:var(--series-{esc(b)})"></span>'
        f"{esc(BACKEND_NAMES.get(b, b))}</span>"
        for b in backends
    )
    return f'<div class="legend">{items}</div>'


# ---------------------------------------------------------------------- #
# HTML sections                                                           #
# ---------------------------------------------------------------------- #


def chart_card(
    title: str,
    subtitle: str,
    backends: list[str],
    rows: list[dict],
    x_max: float,
    ticks: list[float],
    tick_label,
    tip_value,
    table_headers: list[str],
    table_rows: list[list[str]],
) -> str:
    thead = "".join(f"<th>{esc(h)}</th>" for h in table_headers)
    tbody = "".join(
        "<tr>" + "".join(
            f'<td class="{"num" if i else ""}">{cell}</td>'
            for i, cell in enumerate(r)
        ) + "</tr>"
        for r in table_rows
    )
    return f"""
<section class="card">
  <h2>{esc(title)}</h2>
  <p class="sub">{esc(subtitle)}</p>
  {legend(backends)}
  {grouped_hbar(rows, backends, x_max, ticks, tick_label, tip_value)}
  <details class="tableview">
    <summary>Table view</summary>
    <table><thead><tr>{thead}</tr></thead><tbody>{tbody}</tbody></table>
  </details>
</section>"""


def _embed_png(path: Path) -> str:
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:image/png;base64,{data}"


def experiment_section(
    experiment: str,
    backends: list[str],
    latest: dict[tuple[str, str], Run],
) -> str:
    runs = {b: latest.get((b, experiment)) for b in backends}
    if not any(runs.values()):
        return ""

    # Metric table: headline metrics first (report order), then the rest.
    metric_names: list[str] = []
    for m in HEADLINE_METRICS.get(experiment, []):
        if any(r and m in r.summary for r in runs.values()):
            metric_names.append(m)
    for r in runs.values():
        if not r:
            continue
        for m in r.summary:
            if m not in metric_names:
                metric_names.append(m)

    head = "".join(
        f"<th>{esc(BACKEND_NAMES.get(b, b))}</th>" for b in backends
    )
    body_rows = []
    for m in metric_names:
        cells = "".join(
            f'<td class="num">'
            f"{esc(fmt_value(runs[b].summary.get(m)) if runs[b] else '—')}</td>"
            for b in backends
        )
        body_rows.append(f"<tr><td><code>{esc(m)}</code></td>{cells}</tr>")

    run_line = " · ".join(
        f"{esc(BACKEND_NAMES.get(b, b))}: <code>{esc(runs[b].run_id)}</code>"
        for b in backends
        if runs[b]
    )

    figures = []
    for b in backends:
        r = runs[b]
        if not r:
            continue
        for p in r.plots:
            figures.append(
                f'<figure><img src="{_embed_png(p)}" alt="{esc(b)} {esc(p.stem)}" '
                f'loading="lazy"/><figcaption>{esc(BACKEND_NAMES.get(b, b))} — '
                f"{esc(p.stem.replace('_', ' '))}</figcaption></figure>"
            )
    figures_html = f'<div class="plots">{"".join(figures)}</div>' if figures else ""

    note = ""
    if experiment == "leakage":
        note = (
            '<p class="note">Note: the Memory Fleet run of record measured the '
            "GET-by-id enforcement gap (scope leak rate 1.0), which was "
            "subsequently remediated server-side — the re-probe in "
            "<code>agent_scope_leakage-2f77f908</code> shows 0/96 cross-fleet "
            "leaks at trust 1. See <code>data/traces/README.md</code>.</p>"
        )

    return f"""
<section class="card">
  <h2>{esc(experiment.capitalize())}</h2>
  <p class="sub">{esc(EXPERIMENT_BLURBS.get(experiment, ""))}</p>
  <p class="runline">Latest runs — {run_line}</p>
  {note}
  <div class="tablewrap">
  <table><thead><tr><th>Metric</th>{head}</tr></thead>
  <tbody>{''.join(body_rows)}</tbody></table>
  </div>
  {figures_html}
</section>"""


def all_runs_section(runs: list[Run]) -> str:
    key_metric_by_exp = {
        "leakage": "leak_rate",
        "contradiction": "detection_rate",
        "provenance": "completeness_rate",
        "propagation": "fleet_visibility_rate",
    }
    rows = []
    for r in runs:
        key_m = key_metric_by_exp.get(r.experiment)
        key_v = fmt_value(r.summary.get(key_m)) if key_m else "—"
        key_cell = f"<code>{esc(key_m)}</code> = {esc(key_v)}" if key_m else "—"
        started = (r.started_at or "—").replace("T", " ")[:19]
        smoke = ' <span class="chip">smoke</span>' if r.is_smoke else ""
        rows.append(
            f"<tr><td><code>{esc(r.run_id)}</code>{smoke}</td>"
            f"<td>{esc(r.experiment)}</td>"
            f"<td>{esc(BACKEND_NAMES.get(r.backend, r.backend))}</td>"
            f'<td class="num">{esc(r.seed if r.seed is not None else "—")}</td>'
            f'<td class="num">{esc(started)}</td>'
            f"<td>{key_cell}</td>"
            f"<td>{esc(r.source)}</td></tr>"
        )
    return f"""
<section class="card">
  <h2>All runs</h2>
  <p class="sub">Every run directory discovered under the data folder,
  newest first. Smoke runs use tiny N and are excluded from the headline
  charts above.</p>
  <div class="tablewrap">
  <table><thead><tr><th>Run</th><th>Experiment</th><th>Backend</th>
  <th>Seed</th><th>Started (UTC)</th><th>Key metric</th><th>Source</th></tr></thead>
  <tbody>{''.join(rows)}</tbody></table>
  </div>
</section>"""


# ---------------------------------------------------------------------- #
# Page                                                                    #
# ---------------------------------------------------------------------- #

CSS = """
:root {
  color-scheme: light;
  --page: #f9f9f7; --surface-1: #fcfcfb;
  --text-primary: #0b0b0b; --text-secondary: #52514e; --muted: #898781;
  --grid: #e1e0d9; --axis: #c3c2b7; --border: rgba(11,11,11,0.10);
  --series-memoryfleet: #2a78d6; --series-mem0: #eb6834;
}
@media (prefers-color-scheme: dark) {
  :root:where(:not([data-theme="light"])) {
    color-scheme: dark;
    --page: #0d0d0d; --surface-1: #1a1a19;
    --text-primary: #ffffff; --text-secondary: #c3c2b7; --muted: #898781;
    --grid: #2c2c2a; --axis: #383835; --border: rgba(255,255,255,0.10);
    --series-memoryfleet: #3987e5; --series-mem0: #d95926;
  }
}
:root[data-theme="dark"] {
  color-scheme: dark;
  --page: #0d0d0d; --surface-1: #1a1a19;
  --text-primary: #ffffff; --text-secondary: #c3c2b7; --muted: #898781;
  --grid: #2c2c2a; --axis: #383835; --border: rgba(255,255,255,0.10);
  --series-memoryfleet: #3987e5; --series-mem0: #d95926;
}
* { box-sizing: border-box; }
body {
  margin: 0; background: var(--page); color: var(--text-primary);
  font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
  font-size: 14px; line-height: 1.5;
}
.wrap { max-width: 980px; margin: 0 auto; padding: 24px 20px 60px; }
header.page { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; }
header.page h1 { font-size: 22px; margin: 0; }
header.page .sub { color: var(--text-secondary); margin: 0; }
#theme-toggle {
  margin-left: auto; border: 1px solid var(--border); background: var(--surface-1);
  color: var(--text-secondary); border-radius: 8px; padding: 4px 12px;
  font: inherit; font-size: 12px; cursor: pointer;
}
.kpis { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 12px; margin: 20px 0; }
.kpi { background: var(--surface-1); border: 1px solid var(--border);
  border-radius: 10px; padding: 12px 16px; }
.kpi .label { font-size: 12px; color: var(--text-secondary); }
.kpi .value { font-size: 26px; font-weight: 600; }
.card { background: var(--surface-1); border: 1px solid var(--border);
  border-radius: 10px; padding: 20px 24px; margin: 20px 0; }
.card h2 { font-size: 16px; margin: 0 0 4px; }
.card .sub { color: var(--text-secondary); margin: 0 0 12px; font-size: 13px; }
.card .runline { color: var(--muted); font-size: 12px; margin: 0 0 12px; }
.card .note { color: var(--text-secondary); font-size: 12.5px;
  border-left: 3px solid var(--axis); padding-left: 10px; margin: 0 0 12px; }
.legend { display: flex; gap: 18px; margin: 0 0 10px; font-size: 12.5px;
  color: var(--text-secondary); }
.legend .key { display: inline-flex; align-items: center; gap: 6px; }
.legend .swatch { width: 12px; height: 12px; border-radius: 3px; display: inline-block; }
code { font-family: ui-monospace, Consolas, monospace; font-size: 0.92em;
  color: var(--text-secondary); }
.tablewrap { overflow-x: auto; }
table { border-collapse: collapse; width: 100%; font-size: 13px; }
th, td { text-align: left; padding: 5px 12px 5px 0; border-bottom: 1px solid var(--grid); }
th { color: var(--text-secondary); font-weight: 600; }
td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; }
details.tableview { margin-top: 10px; }
details.tableview summary { cursor: pointer; color: var(--text-secondary); font-size: 13px; }
.plots { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 14px; margin-top: 16px; }
.plots figure { margin: 0; }
.plots img { width: 100%; height: auto; background: #fff; border-radius: 6px;
  border: 1px solid var(--border); }
.plots figcaption { font-size: 12px; color: var(--muted); margin-top: 4px; }
.chip { font-size: 10.5px; border: 1px solid var(--border); border-radius: 999px;
  padding: 1px 7px; color: var(--muted); vertical-align: 1px; }
svg rect[data-tip]:focus { outline: 1px solid var(--axis); outline-offset: -1px; }
#tooltip {
  position: fixed; pointer-events: none; display: none; z-index: 10;
  background: var(--surface-1); color: var(--text-primary);
  border: 1px solid var(--border); border-radius: 8px; padding: 6px 10px;
  font-size: 12.5px; max-width: 340px;
  box-shadow: 0 4px 14px rgba(0,0,0,0.12);
}
footer { color: var(--muted); font-size: 12px; margin-top: 30px; }
"""

JS = """
(function () {
  var root = document.documentElement;
  var btn = document.getElementById('theme-toggle');
  var stored = null;
  try { stored = localStorage.getItem('argus-theme'); } catch (e) {}
  if (stored === 'light' || stored === 'dark') root.dataset.theme = stored;
  function label() {
    var dark = root.dataset.theme === 'dark' ||
      (!root.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches);
    btn.textContent = dark ? 'Light mode' : 'Dark mode';
  }
  btn.addEventListener('click', function () {
    var dark = root.dataset.theme === 'dark' ||
      (!root.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches);
    root.dataset.theme = dark ? 'light' : 'dark';
    try { localStorage.setItem('argus-theme', root.dataset.theme); } catch (e) {}
    label();
  });
  label();

  var tip = document.getElementById('tooltip');
  function show(el) { tip.textContent = el.getAttribute('data-tip'); tip.style.display = 'block'; }
  function hide() { tip.style.display = 'none'; }
  function move(x, y) {
    var pad = 14, w = tip.offsetWidth, h = tip.offsetHeight;
    var left = x + pad, top = y + pad;
    if (left + w > innerWidth - 8) left = x - w - pad;
    if (top + h > innerHeight - 8) top = y - h - pad;
    tip.style.left = left + 'px'; tip.style.top = top + 'px';
  }
  document.addEventListener('mouseover', function (e) {
    var t = e.target.closest('[data-tip]');
    if (t) { show(t); move(e.clientX, e.clientY); } else hide();
  });
  document.addEventListener('mousemove', function (e) {
    if (tip.style.display === 'block') move(e.clientX, e.clientY);
  });
  document.addEventListener('focusin', function (e) {
    var t = e.target.closest('[data-tip]');
    if (t) { var r = t.getBoundingClientRect(); show(t); move(r.left + 40, r.top); }
  });
  document.addEventListener('focusout', hide);
})();
"""


def build_page(data_dir: Path, runs: list[Run], include_smoke: bool) -> str:
    latest = headline_runs(runs, include_smoke)
    backends = sorted(
        {b for (b, _) in latest}, key=lambda b: (b != "memoryfleet", b)
    )
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    def run_note(exp: str, b: str) -> str:
        r = latest.get((b, exp))
        return f" (run {r.run_id})" if r else ""

    # Rates chart rows.
    rate_rows, rate_table = [], []
    for exp, metric, label_, direction in RATE_ROWS:
        values = {
            b: (latest[(b, exp)].summary.get(metric)
                if (b, exp) in latest else None)
            for b in backends
        }
        if all(v is None for v in values.values()):
            continue
        rate_rows.append({
            "label": label_,
            "values": values,
            "notes": {b: run_note(exp, b) for b in backends},
        })
        rate_table.append(
            [f"{esc(label_)} <span class='chip'>{'↓' if direction == 'lower' else '↑'} better</span>"]
            + [esc(fmt_rate(values[b])) for b in backends]
        )

    # Latency chart rows.
    lat_rows, lat_table = [], []
    lat_max = 0.0
    for exp, metric, label_ in LATENCY_ROWS:
        values = {
            b: (latest[(b, exp)].summary.get(metric)
                if (b, exp) in latest else None)
            for b in backends
        }
        if all(v is None for v in values.values()):
            continue
        lat_max = max([lat_max] + [v for v in values.values() if v is not None])
        lat_rows.append({
            "label": label_,
            "values": values,
            "notes": {b: run_note(exp, b) for b in backends},
        })
        lat_table.append([esc(label_)] + [esc(fmt_ms(values[b])) for b in backends])
    lat_ceiling = nice_ceiling(lat_max)

    n_exps = len({e for (_, e) in latest})
    started = [r.started_at or "" for r in runs if r.started_at]
    latest_ts = max(started)[:10] if started else "—"

    kpis = f"""
<div class="kpis">
  <div class="kpi"><div class="label">Runs discovered</div><div class="value">{len(runs)}</div></div>
  <div class="kpi"><div class="label">Platforms</div><div class="value">{len(backends)}</div></div>
  <div class="kpi"><div class="label">Experiments covered</div><div class="value">{n_exps}</div></div>
  <div class="kpi"><div class="label">Most recent run</div><div class="value" style="font-size:18px">{esc(latest_ts)}</div></div>
</div>"""

    tick_steps = 5
    lat_ticks = [lat_ceiling * i / tick_steps for i in range(tick_steps + 1)]

    sections = [
        chart_card(
            "Architectural correctness — headline rates",
            "Latest full run per platform and experiment. All rates are in "
            "[0, 1]; whether high or low is good depends on the metric — "
            "see the table view.",
            backends, rate_rows, 1.0,
            [0, 0.25, 0.5, 0.75, 1.0],
            lambda t: f"{t:g}", fmt_rate,
            ["Metric"] + [BACKEND_NAMES.get(b, b) for b in backends],
            rate_table,
        ),
        chart_card(
            "Operation latency — p50",
            "Median wall-clock latency per operation type, milliseconds "
            "(same axis for both platforms).",
            backends, lat_rows, lat_ceiling,
            lat_ticks,
            lambda t: f"{t:,.0f}", fmt_ms,
            ["Operation"] + [BACKEND_NAMES.get(b, b) for b in backends],
            lat_table,
        ),
    ]
    for exp in KNOWN_EXPERIMENTS:
        sections.append(experiment_section(exp, backends, latest))
    sections.append(all_runs_section(runs))

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>ArgusFleet — Results Dashboard</title>
<style>{CSS}</style>
</head>
<body>
<div class="wrap">
<header class="page">
  <h1>ArgusFleet — Results Dashboard</h1>
  <p class="sub">Governed shared memory for multi-agent LLM systems · Memory Fleet vs Mem0</p>
  <button id="theme-toggle" type="button">Dark mode</button>
</header>
{kpis}
{''.join(sections)}
<footer>Generated {esc(now)} from the <code>{esc(data_dir.name)}/</code> directory by build_dashboard.py.
All workloads are synthetic and seed-derived; every number is reproducible from the
run's <code>events.jsonl</code>.</footer>
</div>
<div id="tooltip" role="status"></div>
<script>{JS}</script>
</body>
</html>"""


def default_data_dir(script_path: Path) -> Path | None:
    candidates = [
        script_path.parent.parent.parent / "data",  # bundle layout
        Path.cwd() / "data",
        Path.cwd() / "outputs",
    ]
    for c in candidates:
        if (c / "runs").is_dir() or any(
            (c / n).is_dir() for n in ("traces",)
        ):
            return c
    return None


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--data", type=Path, default=None,
                    help="data directory containing runs/ (default: auto-locate)")
    ap.add_argument("--out", type=Path, default=Path("dashboard.html"),
                    help="output HTML file (default: dashboard.html)")
    ap.add_argument("--include-smoke", action="store_true",
                    help="allow smoke runs into the headline selection")
    args = ap.parse_args(argv)

    data_dir = args.data or default_data_dir(Path(__file__).resolve())
    if data_dir is None or not data_dir.is_dir():
        print("error: could not locate the data directory — pass --data",
              file=sys.stderr)
        return 2

    runs = discover_runs(data_dir)
    if not runs:
        print(f"error: no runs with events.jsonl found under {data_dir}",
              file=sys.stderr)
        return 2

    page = build_page(data_dir, runs, args.include_smoke)
    args.out.write_text(page, encoding="utf-8")
    size_kb = args.out.stat().st_size / 1024
    print(f"wrote {args.out} ({size_kb:,.0f} KB) — {len(runs)} runs, "
          f"open it in a browser")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
