# ArgusFleet — Latest Results

_Generated 2026-05-29 12:43:43 UTC_

## Headline

| Experiment | Run directory | Started (UTC) |
| --- | --- | --- |
| leakage | `20260529T124011Z-leakage-seed42` | 2026-05-29T12:40:12.125454+00:00 |
| contradiction | `20260529T124033Z-contradiction-seed42` | 2026-05-29T12:40:33.759628+00:00 |
| provenance | `20260529T124223Z-provenance-seed42` | 2026-05-29T12:42:23.437638+00:00 |
| propagation | `20260529T124225Z-propagation-seed42` | 2026-05-29T12:42:25.901765+00:00 |

## leakage

Run dir: `outputs\runs\20260529T124011Z-leakage-seed42`

| Metric | Value |
| --- | ---: |
| n_probes | 96 |
| n_expected_allow | 16 |
| n_expected_deny | 80 |
| n_leaks | 0 |
| leak_rate | 0 |
| leak_rate_ci95_lo | 0 |
| leak_rate_ci95_hi | 0.0458 |
| n_misses | 0 |
| miss_rate | 0 |
| miss_rate_ci95_lo | 0 |
| miss_rate_ci95_hi | 0.1936 |
| search_leak_rate | 0 |
| search_miss_rate | 1 |
| access_latency_p50 | 0 |
| access_latency_p95 | 0 |
| search_latency_p50 | 613.8306 |
| search_latency_p95 | 931.0836 |
| n_search_leaks | 0 |
| n_search_misses | 16 |
| n_violations | 0 |
| n_writes | 8 |
| search_latency_count | 96 |
| search_latency_mean | 655.3327 |
| search_latency_p99 | 1.03e+03 |
| access_latency_count | 0 |
| access_latency_mean | 0 |
| access_latency_p99 | 0 |

Plots:
- `leakage_by_axis.png` (`outputs\runs\20260529T124011Z-leakage-seed42\leakage_by_axis.png`)
- `search_latency.png` (`outputs\runs\20260529T124011Z-leakage-seed42\search_latency.png`)

## contradiction

Run dir: `outputs\runs\20260529T124033Z-contradiction-seed42`

| Metric | Value |
| --- | ---: |
| n_facts_runs | 100 |
| detection_rate | 0 |
| stale_read_rate | 0 |
| write_latency_p50 | 0 |
| write_latency_p95 | 0 |
| n_detected | 0 |
| n_stale_reads | 0 |
| n_writes | 200 |
| write_latency_count | 0 |
| write_latency_mean | 0 |
| write_latency_p99 | 0 |
| write_latency_with_contradiction_count | 0 |
| write_latency_with_contradiction_mean | 0 |
| write_latency_with_contradiction_p50 | 0 |
| write_latency_with_contradiction_p95 | 0 |
| write_latency_with_contradiction_p99 | 0 |
| write_latency_no_contradiction_count | 0 |
| write_latency_no_contradiction_mean | 0 |
| write_latency_no_contradiction_p50 | 0 |
| write_latency_no_contradiction_p95 | 0 |
| write_latency_no_contradiction_p99 | 0 |

Plots:
- `detection_rate.png` (`outputs\runs\20260529T124033Z-contradiction-seed42\detection_rate.png`)
- `write_latency.png` (`outputs\runs\20260529T124033Z-contradiction-seed42\write_latency.png`)

## provenance

Run dir: `outputs\runs\20260529T124223Z-provenance-seed42`

| Metric | Value |
| --- | ---: |
| n_chains | 25 |
| completeness_rate | 0 |
| accuracy_rate | 0 |
| depth_fidelity_rate | 0 |
| n_writes | 26 |
| n_fetches | 0 |

Plots:
- `completeness_by_depth.png` (`outputs\runs\20260529T124223Z-provenance-seed42\completeness_by_depth.png`)

## propagation

Run dir: `outputs\runs\20260529T124225Z-propagation-seed42`

| Metric | Value |
| --- | ---: |
| fleet_visibility_rate | 1 |
| leak_rate | 0 |
| n_missed_propagations | 0 |
| ownership_transfer_rate | 0 |
| t_visible_p50 | 3.35e+04 |
| t_visible_p95 | 4e+04 |
| n_writes | 20 |
| n_visibility_probes | 15 |
| n_fleet_probes | 9 |
| n_foreign_probes | 6 |
| t_visible_count | 9 |
| t_visible_mean | 2.91e+04 |
| t_visible_p99 | 4e+04 |
| n_redistributes | 1 |

Plots:
- `time_to_visibility.png` (`outputs\runs\20260529T124225Z-propagation-seed42\time_to_visibility.png`)
- `visibility_by_relation.png` (`outputs\runs\20260529T124225Z-propagation-seed42\visibility_by_relation.png`)
