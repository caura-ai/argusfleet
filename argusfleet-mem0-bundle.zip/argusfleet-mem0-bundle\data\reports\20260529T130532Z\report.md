# ArgusFleet — Latest Results

_Generated 2026-05-29 13:05:32 UTC_

## Headline

| Experiment | Run directory | Started (UTC) |
| --- | --- | --- |
| leakage | `20260529T125924Z-leakage-seed42` | 2026-05-29T12:59:24.812061+00:00 |
| contradiction | `20260529T125954Z-contradiction-seed42` | 2026-05-29T12:59:54.472269+00:00 |
| provenance | `20260529T130126Z-provenance-seed42` | 2026-05-29T13:01:27.130153+00:00 |
| propagation | `20260529T130138Z-propagation-seed42` | 2026-05-29T13:01:39.068317+00:00 |

## leakage

Run dir: `outputs\runs\20260529T125924Z-leakage-seed42`

| Metric | Value |
| --- | ---: |
| n_probes | 96 |
| n_expected_allow | 16 |
| n_expected_deny | 80 |
| n_leaks | 80 |
| leak_rate | 1 |
| leak_rate_ci95_lo | 0.9542 |
| leak_rate_ci95_hi | 1 |
| n_misses | 0 |
| miss_rate | 0 |
| miss_rate_ci95_lo | 0 |
| miss_rate_ci95_hi | 0.1936 |
| search_leak_rate | 0.425 |
| search_miss_rate | 0.25 |
| access_latency_p50 | 306.496 |
| access_latency_p95 | 641.4598 |
| search_latency_p50 | 626.5385 |
| search_latency_p95 | 974.3211 |
| n_search_leaks | 34 |
| n_search_misses | 4 |
| n_violations | 80 |
| n_writes | 8 |
| search_latency_count | 96 |
| search_latency_mean | 737.1789 |
| search_latency_p99 | 2.11e+03 |
| access_latency_count | 96 |
| access_latency_mean | 346.3132 |
| access_latency_p99 | 704.5321 |

Plots:
- `leakage_by_axis.png` (`outputs\runs\20260529T125924Z-leakage-seed42\leakage_by_axis.png`)
- `search_latency.png` (`outputs\runs\20260529T125924Z-leakage-seed42\search_latency.png`)

## contradiction

Run dir: `outputs\runs\20260529T125954Z-contradiction-seed42`

| Metric | Value |
| --- | ---: |
| n_facts_runs | 100 |
| detection_rate | 0 |
| stale_read_rate | 0 |
| write_latency_p50 | 2.04e+03 |
| write_latency_p95 | 4.6e+03 |
| n_detected | 0 |
| n_stale_reads | 0 |
| n_writes | 200 |
| write_latency_count | 74 |
| write_latency_mean | 2.46e+03 |
| write_latency_p99 | 7.17e+03 |
| write_latency_with_contradiction_count | 0 |
| write_latency_with_contradiction_mean | 0 |
| write_latency_with_contradiction_p50 | 0 |
| write_latency_with_contradiction_p95 | 0 |
| write_latency_with_contradiction_p99 | 0 |
| write_latency_no_contradiction_count | 74 |
| write_latency_no_contradiction_mean | 2.46e+03 |
| write_latency_no_contradiction_p50 | 2.04e+03 |
| write_latency_no_contradiction_p95 | 4.6e+03 |
| write_latency_no_contradiction_p99 | 7.17e+03 |

Plots:
- `detection_rate.png` (`outputs\runs\20260529T125954Z-contradiction-seed42\detection_rate.png`)
- `write_latency.png` (`outputs\runs\20260529T125954Z-contradiction-seed42\write_latency.png`)

## provenance

Run dir: `outputs\runs\20260529T130126Z-provenance-seed42`

| Metric | Value |
| --- | ---: |
| n_chains | 25 |
| completeness_rate | 0.56 |
| accuracy_rate | 0.56 |
| depth_fidelity_rate | 0.56 |
| fetch_latency_p50 | 295.0692 |
| fetch_latency_p95 | 410.585 |
| n_writes | 77 |
| n_fetches | 56 |
| fetch_latency_count | 56 |
| fetch_latency_mean | 309.4786 |
| fetch_latency_p99 | 430.2566 |

Plots:
- `completeness_by_depth.png` (`outputs\runs\20260529T130126Z-provenance-seed42\completeness_by_depth.png`)
- `fetch_latency.png` (`outputs\runs\20260529T130126Z-provenance-seed42\fetch_latency.png`)

## propagation

Run dir: `outputs\runs\20260529T130138Z-propagation-seed42`

| Metric | Value |
| --- | ---: |
| fleet_visibility_rate | 0.95 |
| leak_rate | 0 |
| n_missed_propagations | 3 |
| ownership_transfer_rate | 0 |
| t_visible_p50 | 8.95e+04 |
| t_visible_p95 | 1.38e+05 |
| n_writes | 20 |
| n_visibility_probes | 100 |
| n_fleet_probes | 60 |
| n_foreign_probes | 40 |
| t_visible_count | 57 |
| t_visible_mean | 9.29e+04 |
| t_visible_p99 | 1.55e+05 |
| n_redistributes | 10 |

Plots:
- `time_to_visibility.png` (`outputs\runs\20260529T130138Z-propagation-seed42\time_to_visibility.png`)
- `visibility_by_relation.png` (`outputs\runs\20260529T130138Z-propagation-seed42\visibility_by_relation.png`)
