# ArgusFleet — Latest Results

_Generated 2026-05-30 15:37:20 UTC_

## Headline

| Experiment | Run directory | Started (UTC) |
| --- | --- | --- |
| leakage | `20260530T153048Z-leakage-seed42` | 2026-05-30T15:30:48.612909+00:00 |
| contradiction | `20260530T153139Z-contradiction-seed42` | 2026-05-30T15:31:39.461845+00:00 |
| provenance | `20260530T153446Z-provenance-seed42` | 2026-05-30T15:34:46.734131+00:00 |
| propagation | `20260530T153521Z-propagation-seed42` | 2026-05-30T15:35:21.403380+00:00 |

## leakage

Run dir: `outputs\runs\20260530T153048Z-leakage-seed42`

| Metric | Value |
| --- | ---: |
| n_probes | 192 |
| n_expected_allow | 28 |
| n_expected_deny | 164 |
| n_leaks | 164 |
| leak_rate | 1 |
| leak_rate_ci95_lo | 0.9771 |
| leak_rate_ci95_hi | 1 |
| n_misses | 0 |
| miss_rate | 0 |
| miss_rate_ci95_lo | 0 |
| miss_rate_ci95_hi | 0.1206 |
| search_leak_rate | 0.439 |
| search_miss_rate | 0.1429 |
| access_latency_p50 | 295.6827 |
| access_latency_p95 | 547.6084 |
| search_latency_p50 | 725.9014 |
| search_latency_p95 | 1.02e+03 |
| n_search_leaks | 72 |
| n_search_misses | 4 |
| n_violations | 164 |
| n_writes | 8 |
| search_latency_count | 192 |
| search_latency_mean | 860.5599 |
| search_latency_p99 | 5.78e+03 |
| access_latency_count | 192 |
| access_latency_mean | 796.4786 |
| access_latency_p99 | 1.5e+04 |

Plots:
- `leakage_by_axis.png` (`outputs\runs\20260530T153048Z-leakage-seed42\leakage_by_axis.png`)
- `search_latency.png` (`outputs\runs\20260530T153048Z-leakage-seed42\search_latency.png`)

## contradiction

Run dir: `outputs\runs\20260530T153139Z-contradiction-seed42`

| Metric | Value |
| --- | ---: |
| n_facts_runs | 200 |
| detection_rate | 0.49 |
| stale_read_rate | 0 |
| write_latency_p50 | 1.84e+03 |
| write_latency_p95 | 4.86e+03 |
| n_detected | 98 |
| n_stale_reads | 0 |
| n_writes | 400 |
| write_latency_count | 194 |
| write_latency_mean | 2.43e+03 |
| write_latency_p99 | 1.93e+04 |
| write_latency_with_contradiction_count | 0 |
| write_latency_with_contradiction_mean | 0 |
| write_latency_with_contradiction_p50 | 0 |
| write_latency_with_contradiction_p95 | 0 |
| write_latency_with_contradiction_p99 | 0 |
| write_latency_no_contradiction_count | 194 |
| write_latency_no_contradiction_mean | 2.43e+03 |
| write_latency_no_contradiction_p50 | 1.84e+03 |
| write_latency_no_contradiction_p95 | 4.86e+03 |
| write_latency_no_contradiction_p99 | 1.93e+04 |

Plots:
- `detection_rate.png` (`outputs\runs\20260530T153139Z-contradiction-seed42\detection_rate.png`)
- `write_latency.png` (`outputs\runs\20260530T153139Z-contradiction-seed42\write_latency.png`)

## provenance

Run dir: `outputs\runs\20260530T153446Z-provenance-seed42`

| Metric | Value |
| --- | ---: |
| n_chains | 50 |
| completeness_rate | 1 |
| accuracy_rate | 1 |
| depth_fidelity_rate | 1 |
| fetch_latency_p50 | 291.3994 |
| fetch_latency_p95 | 491.4429 |
| accuracy_n_eval | 50 |
| n_writes | 200 |
| n_fetches | 200 |
| fetch_latency_count | 200 |
| fetch_latency_mean | 342.5194 |
| fetch_latency_p99 | 1.08e+03 |

Plots:
- `completeness_by_depth.png` (`outputs\runs\20260530T153446Z-provenance-seed42\completeness_by_depth.png`)
- `fetch_latency.png` (`outputs\runs\20260530T153446Z-provenance-seed42\fetch_latency.png`)

## propagation

Run dir: `outputs\runs\20260530T153521Z-propagation-seed42`

| Metric | Value |
| --- | ---: |
| fleet_visibility_rate | 0.9583 |
| leak_rate | 0 |
| n_missed_propagations | 3 |
| ownership_transfer_rate | 0 |
| t_visible_p50 | 6.48e+04 |
| t_visible_p95 | 8.22e+04 |
| n_writes | 40 |
| n_visibility_probes | 120 |
| n_fleet_probes | 72 |
| n_foreign_probes | 48 |
| t_visible_count | 69 |
| t_visible_mean | 6.19e+04 |
| t_visible_p99 | 8.4e+04 |
| n_redistributes | 12 |
| n_redistributes_attempted | 0 |
| ownership_transfer_skipped | 12 |

Plots:
- `time_to_visibility.png` (`outputs\runs\20260530T153521Z-propagation-seed42\time_to_visibility.png`)
- `visibility_by_relation.png` (`outputs\runs\20260530T153521Z-propagation-seed42\visibility_by_relation.png`)
