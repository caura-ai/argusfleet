# ArgusFleet — Latest Results

_Generated 2026-07-13 16:12:45 UTC_

## Headline

| Backend | Experiment | Run directory | Started (UTC) |
| --- | --- | --- | --- |
| memoryfleet | leakage | `20260713T152326Z-leakage-smoke-seed7` | 2026-07-13T15:23:27.142202+00:00 |
| memoryfleet | contradiction | `20260530T171156Z-contradiction-seed42` | 2026-05-30T17:11:56.884892+00:00 |
| memoryfleet | provenance | `20260530T153446Z-provenance-seed42` | 2026-05-30T15:34:46.734131+00:00 |
| memoryfleet | propagation | `20260530T161453Z-propagation-seed42` | 2026-05-30T16:14:53.671750+00:00 |
| mem0 | leakage | `20260713T152734Z-leakage-mem0-seed42` | 2026-07-13T15:27:34.650858+00:00 |
| mem0 | contradiction | `20260713T152923Z-contradiction-mem0-seed42` | 2026-07-13T15:29:23.847576+00:00 |
| mem0 | provenance | `20260713T155319Z-provenance-mem0-seed42` | 2026-07-13T15:53:20.045572+00:00 |
| mem0 | propagation | `20260713T155425Z-propagation-mem0-seed42` | 2026-07-13T15:54:26.037740+00:00 |

## leakage — memoryfleet

Run dir: `outputs\runs\20260713T152326Z-leakage-smoke-seed7`

| Metric | Value |
| --- | ---: |
| n_probes | 16 |
| n_expected_allow | 6 |
| n_expected_deny | 10 |
| n_leaks | 0 |
| leak_rate | 0 |
| leak_rate_ci95_lo | 0 |
| leak_rate_ci95_hi | 0.2775 |
| n_misses | 0 |
| miss_rate | 0 |
| miss_rate_ci95_lo | 0 |
| miss_rate_ci95_hi | 0.3903 |
| search_leak_rate | 0 |
| search_miss_rate | 0 |
| access_latency_p50 | 0 |
| access_latency_p95 | 0 |
| search_latency_p50 | 0 |
| search_latency_p95 | 0 |
| n_search_leaks | 0 |
| n_search_misses | 0 |
| n_violations | 0 |
| n_writes | 4 |
| search_latency_count | 0 |
| search_latency_mean | 0 |
| search_latency_p99 | 0 |
| access_latency_count | 0 |
| access_latency_mean | 0 |
| access_latency_p99 | 0 |

Plots:
- `leakage_by_axis.png` (`outputs\runs\20260713T152326Z-leakage-smoke-seed7\leakage_by_axis.png`)
- `search_latency.png` (`outputs\runs\20260713T152326Z-leakage-smoke-seed7\search_latency.png`)

## contradiction — memoryfleet

Run dir: `outputs\runs\20260530T171156Z-contradiction-seed42`

| Metric | Value |
| --- | ---: |
| n_facts_runs | 200 |
| detection_rate | 0.485 |
| stale_read_rate | 0 |
| write_latency_p50 | 1.81e+03 |
| write_latency_p95 | 2.32e+03 |
| n_detected | 97 |
| n_stale_reads | 0 |
| n_writes | 400 |
| write_latency_count | 194 |
| write_latency_mean | 2.01e+03 |
| write_latency_p99 | 5.32e+03 |
| write_latency_with_contradiction_count | 0 |
| write_latency_with_contradiction_mean | 0 |
| write_latency_with_contradiction_p50 | 0 |
| write_latency_with_contradiction_p95 | 0 |
| write_latency_with_contradiction_p99 | 0 |
| write_latency_no_contradiction_count | 194 |
| write_latency_no_contradiction_mean | 2.01e+03 |
| write_latency_no_contradiction_p50 | 1.81e+03 |
| write_latency_no_contradiction_p95 | 2.32e+03 |
| write_latency_no_contradiction_p99 | 5.32e+03 |

Plots:
- `detection_rate.png` (`outputs\runs\20260530T171156Z-contradiction-seed42\detection_rate.png`)
- `write_latency.png` (`outputs\runs\20260530T171156Z-contradiction-seed42\write_latency.png`)

## provenance — memoryfleet

Run dir: `outputs\runs\20260530T153446Z-provenance-seed42`

| Metric | Value |
| --- | ---: |
| n_chains | 50 |
| completeness_rate | 1 |
| accuracy_rate | 1 |
| depth_fidelity_rate | 1 |
| fetch_latency_p50 | 291.3994 |
| fetch_latency_p95 | 491.4429 |
| accuracy_n_eval | 50 |
| n_writes | 200 |
| n_fetches | 200 |
| fetch_latency_count | 200 |
| fetch_latency_mean | 342.5194 |
| fetch_latency_p99 | 1.08e+03 |

Plots:
- `completeness_by_depth.png` (`outputs\runs\20260530T153446Z-provenance-seed42\completeness_by_depth.png`)
- `fetch_latency.png` (`outputs\runs\20260530T153446Z-provenance-seed42\fetch_latency.png`)

## propagation — memoryfleet

Run dir: `outputs\runs\20260530T161453Z-propagation-seed42`

| Metric | Value |
| --- | ---: |
| fleet_visibility_rate | 0.975 |
| leak_rate | 0 |
| n_missed_propagations | 3 |
| ownership_transfer_rate | 0 |
| t_visible_p50 | 829.1753 |
| t_visible_p95 | 1.63e+03 |
| n_writes | 40 |
| n_visibility_probes | 200 |
| n_fleet_probes | 120 |
| n_foreign_probes | 80 |
| t_visible_count | 8 |
| t_visible_mean | 953.7445 |
| t_visible_p99 | 1.9e+03 |
| window_n | 8 |
| window_visible | 8 |
| window_poll_count_p50 | 1 |
| n_redistributes | 20 |
| n_redistributes_attempted | 0 |
| ownership_transfer_skipped | 20 |

Plots:
- `time_to_visibility.png` (`outputs\runs\20260530T161453Z-propagation-seed42\time_to_visibility.png`)
- `visibility_by_relation.png` (`outputs\runs\20260530T161453Z-propagation-seed42\visibility_by_relation.png`)

## leakage — mem0

Run dir: `outputs\runs\20260713T152734Z-leakage-mem0-seed42`

| Metric | Value |
| --- | ---: |
| n_probes | 768 |
| n_expected_allow | 56 |
| n_expected_deny | 712 |
| n_leaks | 712 |
| leak_rate | 1 |
| leak_rate_ci95_lo | 0.9946 |
| leak_rate_ci95_hi | 1 |
| n_misses | 0 |
| miss_rate | 0 |
| miss_rate_ci95_lo | 0 |
| miss_rate_ci95_hi | 0.0642 |
| search_leak_rate | 0.4607 |
| search_miss_rate | 0 |
| access_latency_p50 | 474.6107 |
| access_latency_p95 | 600.1085 |
| search_latency_p50 | 495.2107 |
| search_latency_p95 | 635.2334 |
| n_search_leaks | 328 |
| n_search_misses | 0 |
| n_violations | 712 |
| n_writes | 16 |
| search_latency_count | 768 |
| search_latency_mean | 520.1838 |
| search_latency_p99 | 1.06e+03 |
| access_latency_count | 768 |
| access_latency_mean | 505.1421 |
| access_latency_p99 | 1.4e+03 |

Plots:
- `leakage_by_axis.png` (`outputs\runs\20260713T152734Z-leakage-mem0-seed42\leakage_by_axis.png`)
- `search_latency.png` (`outputs\runs\20260713T152734Z-leakage-mem0-seed42\search_latency.png`)

## contradiction — mem0

Run dir: `outputs\runs\20260713T152923Z-contradiction-mem0-seed42`

| Metric | Value |
| --- | ---: |
| n_facts_runs | 60 |
| detection_rate | 0 |
| stale_read_rate | 0.0167 |
| write_latency_p50 | 629.1646 |
| write_latency_p95 | 1.11e+03 |
| n_detected | 0 |
| n_stale_reads | 1 |
| n_writes | 120 |
| write_latency_count | 120 |
| write_latency_mean | 690.8764 |
| write_latency_p99 | 1.14e+03 |
| write_latency_with_contradiction_count | 0 |
| write_latency_with_contradiction_mean | 0 |
| write_latency_with_contradiction_p50 | 0 |
| write_latency_with_contradiction_p95 | 0 |
| write_latency_with_contradiction_p99 | 0 |
| write_latency_no_contradiction_count | 120 |
| write_latency_no_contradiction_mean | 690.8764 |
| write_latency_no_contradiction_p50 | 629.1646 |
| write_latency_no_contradiction_p95 | 1.11e+03 |
| write_latency_no_contradiction_p99 | 1.14e+03 |

Plots:
- `detection_rate.png` (`outputs\runs\20260713T152923Z-contradiction-mem0-seed42\detection_rate.png`)
- `write_latency.png` (`outputs\runs\20260713T152923Z-contradiction-mem0-seed42\write_latency.png`)

## provenance — mem0

Run dir: `outputs\runs\20260713T155319Z-provenance-mem0-seed42`

| Metric | Value |
| --- | ---: |
| n_chains | 50 |
| completeness_rate | 1 |
| accuracy_rate | 1 |
| depth_fidelity_rate | 1 |
| fetch_latency_p50 | 476.0063 |
| fetch_latency_p95 | 563.1485 |
| accuracy_n_eval | 50 |
| n_writes | 200 |
| n_fetches | 200 |
| fetch_latency_count | 200 |
| fetch_latency_mean | 505.1313 |
| fetch_latency_p99 | 1.2e+03 |

Plots:
- `completeness_by_depth.png` (`outputs\runs\20260713T155319Z-provenance-mem0-seed42\completeness_by_depth.png`)
- `fetch_latency.png` (`outputs\runs\20260713T155319Z-provenance-mem0-seed42\fetch_latency.png`)

## propagation — mem0

Run dir: `outputs\runs\20260713T155425Z-propagation-mem0-seed42`

| Metric | Value |
| --- | ---: |
| fleet_visibility_rate | 0 |
| leak_rate | 0 |
| n_missed_propagations | 120 |
| ownership_transfer_rate | 0 |
| n_writes | 40 |
| n_visibility_probes | 200 |
| n_fleet_probes | 120 |
| n_foreign_probes | 80 |
| n_redistributes | 20 |
| n_redistributes_attempted | 0 |
| ownership_transfer_skipped | 20 |

Plots:
- `visibility_by_relation.png` (`outputs\runs\20260713T155425Z-propagation-mem0-seed42\visibility_by_relation.png`)
